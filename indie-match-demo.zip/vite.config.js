export default {
  root: '.',
  publicDir: 'public',
  server: {
    open: true,
    host: true
  },
  build: {
    outDir: 'dist'
  }
}
